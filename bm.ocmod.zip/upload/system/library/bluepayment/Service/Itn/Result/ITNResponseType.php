<?php

namespace bluepayment\Service\Itn\Result;

abstract class ITNResponseType
{

}
