<?php

class ModelExtensionPaymentBluepaymentGateway extends Model
{
    public function synchronize()
    {
        var_dump('synchronized');
        die;
    }
}